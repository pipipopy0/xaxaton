TEXTS = {
    "start_new": {
        "ru": "Привет! Выберите ваше текущее время\n(нажмите на кнопку с вашим временем):",
        "en": "Hello! Please select your current timezone\n(click on the button with your time):"
    },

    "start_registered": {
        "ru": "Привет, посмотри, тут есть кнопочки, на которые можно понажимать",
        "en": "Hi! Take a look at the menu below."
    },

    "first_info": {
        "ru": (
            "Календатор — это сервис, который поможет не забыть вам о ваших делах и событиях.\n"
            "Вы можете отправлять ему как текстовые, так и голосовые сообщения — "
            "он извлечет из них суть события и заранее напомнит о нем.\n\n"
            "Также вы можете привязать Google Календарь или Apple Календарь. "
            "Тогда все события, созданные через бота, будут автоматически синхронизироваться с вашим календарем."
        ),
        "en": (
            "Calendator is a service that helps you stay on top of your tasks and events.\n"
            "You can send both text and voice messages, and it will extract the important details "
            "and remind you in advance.\n\n"
            "You can also connect your Google Calendar or Apple Calendar. "
            "All events created through the bot will be automatically synchronized with your calendar."
        ),
    },

    "support": {
        "ru": "Если у вас возникли проблемы или вопросы, напишите нам!",
        "en": "If you have any problems or questions, contact us!"
    },

    "timezone_setup": {
        "ru": "Выберите ваше текущее время\n(нажмите на кнопку с вашим временем):",
        "en": "Select your current timezone\n(click on the button with your time):"
    },

    "timezone_set": {
        "ru": "Отлично. Ваш часовой пояс: UTC{offset:+d}\nМожем поставить напоминания.\n\nПросто отправьте мне сообщение, в котором будет информация о событии.\nВы также можете перейти в меню: /start",
        "en": "Great. Your timezone is: UTC{offset:+d}\nWe can set up reminders.\n\nJust send me a message with information about the event.\nYou can also go to the menu: /start"
    },

    "delete_confirmation": {
        "ru": "ВЫ УВЕРЕНЫ? ВСЕ ДАННЫЕ БУДУТ УДАЛЕНЫ",
        "en": "ARE YOU SURE? ALL DATA WILL BE DELETED"
    },

    "delete_success": {
        "ru": "Данные удалены. Если хочешь начать заново, нажми /start",
        "en": "Data deleted. If you want to start over, press /start"
    },

    "delete_cancel": {
        "ru": "Удаление отменено.",
        "en": "Deletion cancelled."
    },

    "update_notifications": {
        "ru": "Вы хотите, чтобы я уведомлял вам о событиях не только в момент их наступления, но и заранее?",
        "en": "Do you want me to notify you about events not only at the time they occur, but also in advance?"
    },

    "notification_time_prompt": {
        "ru": "Напишите, за сколько минут до события вы хотите получать уведомление (например, 30):",
        "en": "Write how many minutes before the event you want to receive a notification (e.g., 30):"
    },

    "notification_time_set": {
        "ru": "Хорошо! Я буду уведомлять вас за {minutes} минут до события.",
        "en": "Okay! I will notify you {minutes} minutes before the event."
    },

    "notification_time_invalid": {
        "ru": "Пожалуйста, введите корректное число минут.",
        "en": "Please enter a valid number of minutes."
    },

    "notification_disabled": {
        "ru": "Хорошо! Я буду уведомлять вас о событиях только в момент их наступления.",
        "en": "Okay! I will only notify you at the time of the event."
    },

    "admin_panel": {
        "ru": "Привет, админ! Твоя админ-панель:",
        "en": "Hello, admin! Your admin panel:"
    },

    "admin_broadcast_prompt": {
        "ru": "Напиши сообщение для рассылки:",
        "en": "Write a message for broadcast:"
    },

    "admin_broadcast_success": {
        "ru": "Сообщение успешно разослано всем пользователям.",
        "en": "Message successfully sent to all users."
    },

    "admin_no_permission": {
        "ru": "У вас нет прав для этого действия.",
        "en": "You don't have permission for this action."
    },

    "calendars_setup": {
        "ru": "Выберите календарь для привязки:",
        "en": "Select a calendar to connect:"
    },

    "apple_email_prompt": {
        "ru": "Напишите email от вашего Apple ID:",
        "en": "Enter your Apple ID email:"
    },

    "apple_password_prompt": {
        "ru": "Теперь напишите ваш app specific password",
        "en": "Now enter your app specific password::"
    },

    "apple_password_link": {
        "ru": "Получить специальный apple пароль",
        "en": "Get an app-specific Apple password"
    },

    "apple_calendar_success": {
        "ru": "Отлично! Ваш календарь привязан.",
        "en": "Great! Your calendar is connected."
    },

    "google_calendar_success": {
        "ru": "Отлично! Ваш календарь привязан через app specific password.",
        "en": "Great! Your calendar is linked via an app specific password."
    },
    "apple_calendar_error": {
        "ru": "Произошла ошибка при сохранении данных. Пожалуйста, попробуйте снова.",
        "en": "An error occurred while saving data. Please try again."
    },

    "user_not_found": {
        "ru": "Пользователь не найден. Сначала используйте /start",
        "en": "User not found. Please use /start first."
    },

    "google_authorization": {
        "ru": "Авторизоваться через google",
        "en": "Please authorize via Google"
    },

    "google_authorized": {
        "ru": "Авторизация прошла успешно!",
        "en": "Authorization successful!"
    },

    "language_changed_ru": {
        "ru": "Русский язык установлен",
        "en": "Russian language set"
    },
    "russian_language": {
        "ru": "Russian",
        "en": "Russian"
    },
    "english_language": {
        "ru": "English",
        "en": "English"
    },

    "language_changed_en": {
        "ru": "Английский язык установлен",
        "en": "English language set"
    },
    "language_change_error": {
        "ru": "Ошибка при изменении языка",
        "en": "Error occurred while changing language"
    },
    "select_language": {
        "ru": "Выберите ваш язык:\nSelect your language",
        "en": "Select your language:\nВыберите ваш язык"
    },

    "not_registered": {
        "ru": "Сначала нажми /start",
        "en": "Please press /start first"
    },

    "need_timezone": {
        "ru": "Пожалуйста, сначала укажи свой часовой пояс.",
        "en": "Please set your timezone first."
    },

    "voice_not_understood": {
        "ru": "Не понял голосовое",
        "en": "Didn't understand the voice message"
    },

    "no_events": {
        "ru": "У вас нет событий.",
        "en": "You don't have any events."
    },

    "no_events_update": {
        "ru": "У вас нет событий для обновления.",
        "en": "You don't have any events to update."
    },

    "no_events_delete": {
        "ru": "У вас нет событий для удаления.",
        "en": "You don't have any events to delete."
    },

    "unsupported_action": {
        "ru": "Есть проблема с пониманием вашего запроса",
        "en": "There's a problem understanding your request"
    },

    "daily_summary_not_implemented": {
        "ru": "Сводка пока не реализована",
        "en": "Daily summary is not implemented yet"
    },

    "change_language": {
        "ru": "🌐Настроить язык/Set up the language",
        "en": "🌐Set up the language/Настроить язык"
    },

    "update_notifications_btn": {
        "ru": "🔔Настроить уведомления",
        "en": "🔔Set up notifications"
    },

    "update_time_btn": {
        "ru": "🌎Установить часовой пояс",
        "en": "🌎Set timezone"
    },

    "what_is_kalendator": {
        "ru": "❓Что такое календатор и как им пользоваться?",
        "en": "❓What is Kalendator and how to use it?"
    },

    "connect_calendars": {
        "ru": "🔄Привязать календари",
        "en": "🔄Connect calendars"
    },

    "support_btn": {
        "ru": "🤝Поддержка",
        "en": "🤝Support"
    },

    "admin_panel_btn": {
        "ru": "Админ-панель",
        "en": "Admin panel"
    },

    "admin_broadcast_btn": {
        "ru": "Сообщить об обновлении",
        "en": "Notify about update"
    },

    "admin_future_btn": {
        "ru": "Будущий функционал",
        "en": "Future functionality"
    },

    "google_calendar_btn": {
        "ru": "Google Календарь",
        "en": "Google Calendar"
    },

    "apple_calendar_btn": {
        "ru": "Apple Календарь",
        "en": "Apple Calendar"
    },

    "delete_data_btn": {
        "ru": "Удалить данные",
        "en": "Delete data"
    },

    "cancel_delete_btn": {
        "ru": "Отмена",
        "en": "Cancel"
    },

    "yes_btn": {
        "ru": "Да",
        "en": "Yes"
    },

    "no_btn": {
        "ru": "Нет",
        "en": "No"
    },

    "prev_page_btn": {
        "ru": "Назад",
        "en": "Back"
    },

    "next_page_btn": {
        "ru": "Еще часовые пояса",
        "en": "More timezones"
    },
    "error_ai_response": {
        "ru": "Извините, произошла ошибка при обработке запроса к ИИ, попробуйте чуть позже.",
        "en": "Sorry, there was an error processing the AI request, please try again later."
    },
    "ai_not_understood": {
        "ru": "Извините, я не смог понять ваш запрос. Попробуйте, пожалуйста, переформулировать.",
        "en": "Sorry, I couldn't understand your request. Please try rephrasing it."
    },
    "error": {
        "ru": "Ошибка",
        "en": "Error"
    },
    "close_authorization_page": {
        "ru": "Привязка Google Календаря успешно завершена! Вы можете закрыть эту страницу и вернуться в бот.",
        "en": "Linking Google Calendar has been completed successfully! You can close this page and return to the bot."
    },
    "refresh_token_not_received": {
        "ru": "refresh_token не был получен. Попробуйте снова.",
        "en": "refresh_token was not received. Try again."
    },
    "error_processing_callback": {
        "ru": "Произошла ошибка при обработке callback.",
        "en": "An error occurred while processing the callback."
    },
    "terms_of_service_link": {
        "ru": "https://telegra.ph/Usloviya-ispolzovaniya-servisom-Kalendator-07-08",
        "en": "https://telegra.ph/Terms-of-Service-07-08-20"
    },
    "privacy_policy_link": {
        "ru": "https://telegra.ph/Politika-konfidencialnosti-servisa-Kalendator-07-08",
        "en": "https://telegra.ph/Privacy-Policy-07-08-141"
    },
    "terms_of_service_text": {
        "ru": "Условия пользования",
        "en": "Terms of Service"
    },
    "privacy_policy_text": {
        "ru": "Политика конфиденциальности",
        "en": "Privacy Policy"
    },
    "unsupported_message_type" : {
        "ru": "Извините, пока что я не могу обработать этот тип сообщения. Пожалуйста, отправьте текстовое или голосовое сообщение.",
        "en": "Sorry, I cannot process this type of message yet. Please send a text or voice message."
    },
    "admin_status_services" : {
        "ru" : "Статус сервисов",
        "en" : "Services status"
    },
    "google_specific_password_auth" : {
        "ru" : "Авторизоваться через специальный пароль",
        "en" : "Log in with a special password"
    },
    "google_email_prompt": {
        "ru": "Напишите email от вашего Google аккаунта:",
        "en": "Write an email from your Google account:"
    },
    "google_choosing_auth_option": {
        "ru": "Выберите вариант авторизации(пока что работает только второй)",
        "en": "Select the authorization option (so far only the second one works)"
    },
    "google_password_prompt": {
        "ru": "Теперь напишите ваш app specific password:",
        "en": "Now enter your app specific password:"
    },
    "google_password_link": {
        "ru": "Получить специальный google пароль",
        "en": "Get an app-specific Google password"
    },
    "google_calendar_error": {
        "ru": "Произошла ошибка при сохранении данных. Пожалуйста, попробуйте снова.",
        "en": "An error occurred while saving data. Please try again."
    },
    "google_calendar_oauth": {
        "ru": "Для подключения Google Календаря скопируйте ссылку ниже и откройте её в браузере.\n\n{url}\n\nНе открывайте ссылку внутри Telegram — иначе может возникнуть ошибка.",
        "en": "To connect Google Calendar, copy the link below and open it in your browser.\n\n{url}\n\nDo not open the link inside Telegram, otherwise an error may occur."
    },
    "google_calendar_activated_already": {
        "ru": "Вы уже привязали Google календарь",
        "en": "You have already linked Google Calendar"
    },
    "apple_calendar_activated_already": {
        "ru": "Вы уже привязали Apple календарь",
        "en": "You have already linked Apple Calendar"
    },
    "reconnect_calendar" : {
        "ru": "Переподключить календарь",
        "en": "Reconnect the calendar"
    },
    "disconnect_calendar" : {
        "ru": "Отвязать календарь",
        "en": "Unlink the calendar"
    },
    "calendar_disconnected" : {
        "ru": "Ваш календарь успешно отвязан",
        "en": "Your calendar has been successfully unlinked"
    },
    "user_not_found" : {
        "ru": "Извините, не смогли найти вас, попробуйте удалить ваши данные через /delete_data и повторно зарегистрироваться через /start",
        "en": "Sorry, we couldn't find you, try deleting your data via /delete_data and re-registering via /start"
    },
    "settings_btn" : {
        "ru": "⚙️Настройки",
        "en": "⚙️Settings"
    },
    "documents_btn" : {
        "ru": "📝Документы",
        "en": "📝Documents"
    },
    "back_btn" : {
        "ru": "🔙Вернуться назад",
        "en": "🔙Go back"
    },
    "settings_menu" : {
        "ru": "Меню настройки",
        "en": "Settings Menu"
    },
    "documents_menu" : {
        "ru": "Прочитайте, пожалуйста, наши документы",
        "en": "Please read our documents."
    },
    "access_denied" : {
            "ru": "Вы исчерпали бесплатный лимит (7 событий в месяц). Чтобы продолжить пользоваться сервисом, пожалуйста, оформите подписку, нажав на /subscribe.",
            "en": "You have exceeded the free limit (7 events per month). To continue using the service, please subscribe by clicking on /subscribe."
    },
    "subscription_lifetime": {
        "ru": "бессрочно",
        "en": "lifetime"
    },
    "subscription_expires_with_days": {
        "ru": "до {date} (осталось: {days} дн.)",
        "en": "until {date} ({days} days left)"
    },
    "subscription_expired": {
        "ru": "истекла",
        "en": "expired"
    },
    "subscription_status_pro": {
        "ru": "У вас активна подписка Pro\n{expires_at}",
        "en": "You have an active Pro subscription\n{expires_at}"
    },
    "subscription_status_free": {
        "ru": "У вас бесплатная версия (7 событий за всё время).\nКупите Pro для безлимита.",
        "en": "You are on the free version (7 events total).\nBuy Pro for unlimited."
    },
    "subscription_buy_pro_btn": {
        "ru": "Купить Pro",
        "en": "Buy Pro"
    },
    "subscription_pro_unavailable": {
        "ru": "Тариф Pro временно недоступен. Попробуйте позже.",
        "en": "Pro plan is temporarily unavailable. Please try again later."
    },
    "subscription_already_active": {
        "ru": "У вас уже активна подписка Pro.",
        "en": "You already have an active Pro subscription."
    },
    "subscription_payment_error": {
        "ru": "Ошибка при создании платежа. Попробуйте позже.",
        "en": "Error creating payment. Please try again later."
    },
    "subscription_payment_link": {
    "ru": "Перейдите по ссылке для оплаты:\n{payment_url}\n\n"
          "После успешной оплаты Pro будет активирован на 30 суток.",
    "en": "Follow the link to pay:\n{payment_url}\n\n"
          "After successful payment, Pro will be activated for 30 days."
    },
    "subscription_not_active": {
        "ru": "Нет активной подписки.",
        "en": "No active subscription."
    },
    "subscription_no_expiration": {
        "ru": "У вас бессрочная подписка, отключение не требуется.",
        "en": "You have a lifetime subscription, no need to disable."
    },
    "manage_subscription": {
        "ru": "🎫Управление подпиской",
        "en": "🎫Manage subscription"
    },
    "pro_activated": {
        "ru": "Pro активирован!\n\n"
          "Подписка действует 30 дней.\n"
          "Теперь вам доступны все функции Calendator без ограничений.\n\n"
          "Можете пользоваться ботом на полную катушку.\n\n",
        "en": "Pro activated!\n\n"
          "Your subscription is active for 30 days.\n"
          "You now have access to all Calendator features without limits."
          },
    "voice_too_long" : {
        "ru": "Извините, я не могу обработать голосовое сообщение дольше 2 минут. Пожалуйста, отправьте более короткое сообщение.",
        "en": "Sorry, I cannot process voice messages longer than 2 minutes. Please send a shorter message."
    },
    "calendars_pro_only" : {
        "ru": "Привязка календарей доступна только для пользователей с подпиской Pro. Пожалуйста, оформите подписку, чтобы использовать эту функцию.",
        "en": "Calendar linking is only available for Pro subscription users. Please subscribe to use this feature."
    },
    "subscription_payment_method": {
    "ru": "Выберите вариант Pro:\n\n"
          "249 ₽ — разовая оплата на 30 суток.\n"
          "229 ₽ — с автопродлением каждые 30 суток.\n\n"
          "При автопродлении карта сохраняется, а платежи будут списываться автоматически.\n\n"
          "Вы сможете отменить автопродление в любой момент времени через управление подпиской",
    "en": "Choose your Pro option:\n\n"
          "249 RUB — one-time payment for 30 days.\n"
          "229 RUB — with automatic renewal every 30 days.\n\n"
          "With automatic renewal, your card will be saved and payments will be charged automatically.\n\n"
          "You can cancel automatic renewal at any time through subscription management."
    },
    "subscription_one_time_btn": {
        "ru": "249 ₽ — Разово",
        "en": "249 RUB — One-time"
    },

    "subscription_auto_payment_btn": {
        "ru": "229 ₽ — Автопродление",
        "en": "229 RUB — Auto-renewal"
    },

    "subscription_auto_payment_link": {
        "ru": "Оплата Pro с автопродлением:\n\n"
            "{payment_url}\n\n"
            "229 ₽ будет списываться автоматически каждые 30 суток.",
        "en": "Pro payment with automatic renewal:\n\n"
            "{payment_url}\n\n"
            "229 RUB will be charged automatically every 30 days."
    },
    "pro_auto_activated": {
    "ru": "Pro активирован!\n\nАвтопродление включено.\nПодписка действует до {expires_at}.",
    "en": "Pro activated!\n\nAutomatic renewal is enabled.\nYour subscription is active until {expires_at}."
    },

    "pro_renewed": {
        "ru": "Pro продлён!\n\nПодписка действует до {expires_at}.",
        "en": "Pro renewed!\n\nYour subscription is active until {expires_at}."
    },

    "pro_auto_renewed": {
        "ru": "Pro автоматически продлён!\n\nПодписка действует до {expires_at}.",
        "en": "Pro automatically renewed!\n\nYour subscription is active until {expires_at}."
    },
    "subscription_expiring_soon_auto": {
        "ru": "Через 3 дня с вашей карты будет списано {amount} ₽ за продление подписки Pro.\nДата списания: {date}.",
        "en": "In 3 days, {amount} RUB will be charged from your card for Pro subscription renewal.\nCharge date: {date}."
    },
    "subscription_expiring_soon_one_time": {
        "ru": "Ваша подписка Pro истекает {date}.\nПродлите её сейчас, чтобы не потерять доступ:\n{payment_url}",
        "en": "Your Pro subscription expires on {date}.\nRenew now to keep access:\n{payment_url}"
    },
    "disable_auto_renewal_btn": {
        "ru": "Отключить автопродление",
        "en": "Disable auto-renewal"
    },
    "auto_renewal_disabled": {
        "ru": "Автопродление отключено.",
        "en": "Auto-renewal has been disabled."
    },
    "google_calendar_instructions" : {
        "ru": "Инструкция по подключению Google Календаря. Пожалуйста, строго следуйте шагам, описанным выше.",
        "en": "Instruction for connecting Google Calendar. Please strictly follow the steps described above."
    },
    "apple_calendar_instructions" : {
        "ru": "Инструкция по подключению Apple Календаря. Пожалуйста, строго следуйте шагам, описанным выше.",
        "en": "Instruction for connecting Apple Calendar. Please strictly follow the steps described above."
    }
}

from logger_config import logger



def get_text(db, key: str, tg_id: str = None, **kwargs) -> str:
    
    tg_id = str(tg_id)
    try:
        language = "ru"#дефолтный язык, если не удалось получить язык пользователя из базы данных
        if db:
            user = db.select_data("users", where_conditions={"tg_id" : tg_id})
            if user and user[0][6]:
                language = user[0][6]

        if language not in ["ru", "en"]:
            language = "ru"
            logger.warning(f"User {tg_id} has unsupported language '{language}', defaulting to 'ru'.")
    
        text = TEXTS.get(key, {}).get(language, "")
        if kwargs and text:
            try:
                text = text.format(**kwargs)
            except Exception as e:
                logger.warning(f"Failed to format text '{key}': {e}")

        return text
    
    except Exception as e:
        logger.error(f"Error retrieving text for key '{key}' and language '{language}': {e}")
        return ""